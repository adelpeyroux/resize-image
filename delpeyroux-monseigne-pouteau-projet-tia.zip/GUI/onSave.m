function onSave(source, event)
global result;
saveImage(result);
end