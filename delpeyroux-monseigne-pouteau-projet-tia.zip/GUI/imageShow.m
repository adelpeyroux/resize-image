function imageShow( axe, im )
axes(axe);
imagesc(axe, im);
axis off;
axis image;
end

